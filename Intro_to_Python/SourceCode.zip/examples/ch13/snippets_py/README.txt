Sections 14.7-11 use one continuous IPython session for the 
examples and Self Check exercises, so all of these are in one
snippet file.
