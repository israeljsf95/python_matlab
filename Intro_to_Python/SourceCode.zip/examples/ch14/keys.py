speech_to_text_key = ''
text_to_speech_key = ''
translate_key = ''